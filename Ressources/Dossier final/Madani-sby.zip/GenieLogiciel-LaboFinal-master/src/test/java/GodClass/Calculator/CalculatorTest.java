/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GodClass.Calculator;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Sebastien
 */
public class CalculatorTest
{
    
    public CalculatorTest()
    {
    }
    
    @BeforeClass
    public static void setUpClass()
    {
    }
    
    @AfterClass
    public static void tearDownClass()
    {
    }

    /**
     * Test of getWcc method, of class Calculator.
     */
    @Test
    public void testGetWcc()
    {
        System.out.println("getWcc");
        /*Calculator instance = new Calculator();
        WeightedMethodCountCalulator expResult = null;
        WeightedMethodCountCalulator result = instance.getWcc();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");*/
    }

    /**
     * Test of getGeneral method, of class Calculator.
     */
    @Test
    public void testGetGeneral()
    {
        System.out.println("getGeneral");
        /*Calculator instance = new Calculator();
        GeneralCalculator expResult = null;
        GeneralCalculator result = instance.getGeneral();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");*/
    }

    /**
     * Test of getClassCohesion method, of class Calculator.
     */
    @Test
    public void testGetClassCohesion()
    {
        System.out.println("getClassCohesion");
        /*Calculator instance = new Calculator();
        ClassCohesionCalculator expResult = null;
        ClassCohesionCalculator result = instance.getClassCohesion();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");*/
    }

    /**
     * Test of setFinalName method, of class Calculator.
     */
    @Test
    public void testSetFinalName()
    {
        System.out.println("setFinalName");
        /*String name = "";
        Calculator instance = new Calculator();
        instance.setFinalName(name);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");*/
    }

    /**
     * Test of getFinalName method, of class Calculator.
     */
    @Test
    public void testGetFinalName()
    {
        System.out.println("getFinalName");
        /*Calculator instance = new Calculator();
        String expResult = "";
        String result = instance.getFinalName();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");*/
    }
    
}
