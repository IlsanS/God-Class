public class DragDropPanel extends javax.swing.JPanel
                           implements DropTargetListener
{
    protected final EventListenerList listeners = new EventListenerList();

    protected DropTarget dropTarget;
    protected boolean dragOver = false;

    public DragDropPanel()
    {
        this.dropTarget = new DropTarget(this, this);
        this.dragOver = false;
    }

    public void addDragDropListener(DragDropListener listener)
    {
        this.listeners.add(DragDropListener.class, listener);
    }

    public void removeDragDropListener(DragDropListener listener)
    {
        this.listeners.remove(DragDropListener.class, listener);
    }

    public DragDropListener[] getDragDropListeners()
    {
        return this.listeners.getListeners(DragDropListener.class);
    }

    protected void fireFileDropped(File file)
    {
        DragDropEvent event = null;
        for (DragDropListener listener : this.getDragDropListeners())
        {
            if (event == null)
                event = new DragDropEvent(this, file);

            listener.fileDropped(event);
        }
    }

    protected void fireFilesDropped(List<File> files)
    {
        if (files.isEmpty())
            return;

        if (files.size() == 1)
        {
            this.fireFileDropped(files.get(0));
        }
        else
        {
            MultipleDragDropEvent event = null;
            for(DragDropListener listener : this.getDragDropListeners())
            {
                if (event == null)
                    event = new MultipleDragDropEvent(this, files);

                listener.filesDropped(event);
            }
        }
    }

    @Override
    protected void paintComponent(Graphics g)
    {
        super.paintComponent(g);

        if (this.dragOver)
            this.setBackground(new Color(209, 245, 189));
        else
            this.setBackground(UIManager.getColor("Panel.background"));
    }

    @Override
    public void dragEnter(DropTargetDragEvent dtde)
    {
        this.dragOver = true;
        repaint();
    }

    @Override
    public void dragOver(DropTargetDragEvent dtde)
    {
    }

    @Override
    public void dropActionChanged(DropTargetDragEvent dtde)
    {
    }

    @Override
    public void dragExit(DropTargetEvent dte)
    {
        this.dragOver = false;
        repaint();
    }

    @Override
    public void drop(DropTargetDropEvent dtde)
    {
        // Accept copy drops
        dtde.acceptDrop(DnDConstants.ACTION_COPY);

        // Update background color
        this.dragOver = false;
        repaint();

        // Get the transfer which can provide the dropped item data
        Transferable transferable = dtde.getTransferable();

        // Get the data formats of the dropped item
        DataFlavor[] flavors = transferable.getTransferDataFlavors();

        // Loop through the flavors
        for (DataFlavor flavor : flavors)
        {
            try
            {
                // If the drop items are files
                if (flavor.isFlavorJavaFileListType())
                {
                    // Get all of the dropped files
                    List transfertData = (List) transferable.getTransferData(flavor);

                    List<File> files = new ArrayList<>();
                    Iterator iter = transfertData.iterator();
                    while (iter.hasNext())
                        files.add((File)iter.next());

                    this.fireFilesDropped(files);
                }

            }
            catch (UnsupportedFlavorException | IOException e)
            {
                e.printStackTrace();
            }
        }

        // Inform that the drop is complete
        dtde.dropComplete(true);
    }
    
    private static final long serialVersionUID = 1L;
}