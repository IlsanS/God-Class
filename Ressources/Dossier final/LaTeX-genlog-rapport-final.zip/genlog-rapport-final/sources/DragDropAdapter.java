public abstract class DragDropAdapter implements DragDropListener
{
    @Override
    public void fileDropped(DragDropEvent event)
    {
        // Nothing to do here ...
    }

    @Override
    public void filesDropped(MultipleDragDropEvent event)
    {
        // Nothing to do here ...
    }
}