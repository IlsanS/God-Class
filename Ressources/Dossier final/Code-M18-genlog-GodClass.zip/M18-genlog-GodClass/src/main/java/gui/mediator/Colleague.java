/*
 * Institut Supérieur Industriel Liégeois - Département ingénieurs industriels
 * Copyright 2015 Mawet Xavier. All rights reserved.
 * http://www.nakim.be
 */
package gui.mediator;

/**
 *
 * @author Nakim
 */
public interface Colleague
{
    public Mediator getMediator();
}
