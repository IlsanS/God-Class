/*
 * Institut Supérieur Industriel Liégeois - Département ingénieurs industriels
 * Copyright 2015 Mawet Xavier. All rights reserved.
 * http://www.nakim.be
 */
package metrics.exceptions;

/**
 *
 * @author Nakim
 */
public class TCCException extends Exception
{
    //<editor-fold defaultstate="collapsed" desc="Constructors">
    public TCCException(String message)
    {
        super(message);
    }
    //</editor-fold>
}
