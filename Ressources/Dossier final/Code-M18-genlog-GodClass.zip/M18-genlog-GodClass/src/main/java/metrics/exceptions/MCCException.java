/*
 * Institut Supérieur Industriel Liègeois - Département ingénieurs industriels.
 * Copyright 2015 Mawet Xavier. All rights reserved.
 * http://www.nakim.be
 */
package metrics.exceptions;

/**
 *
 * @author Nakim
 */
public class MCCException extends Exception
{
    //<editor-fold defaultstate="collapsed" desc="Constructors">
    public MCCException(String string)
    {
        super(string);
    }
    //</editor-fold>
}
