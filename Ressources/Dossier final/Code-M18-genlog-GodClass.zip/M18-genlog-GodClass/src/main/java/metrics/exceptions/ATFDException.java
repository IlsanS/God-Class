/*
 * Institut Supérieur Industriel Liégeois - Département ingénieurs industriels
 * Copyright 2015 Mawet Xavier. All rights reserved.
 * http://www.nakim.be
 */
package metrics.exceptions;

/**
 *
 * @author Nakim
 */
public class ATFDException extends Exception
{
    //<editor-fold defaultstate="collapsed" desc="Constructors">
    public ATFDException(String string)
    {
        super(string);
    }
    //</editor-fold>
}
